"""Configuration utilities (scaffold)."""
from dataclasses import dataclass

@dataclass
class SolverConfig:
    tolerance: float = 1e-8
    max_iters: int = 50


def load_from_dict(d: dict) -> SolverConfig:
    return SolverConfig(**d)
