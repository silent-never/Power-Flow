"""Solvers package exports."""
from . import base_solver, nr_solver
# Optional solvers (may be empty scaffolds)
try:
	from . import pq_solver, cpf_solver, tensor_solver
except Exception:
	# allow imports even if modules are placeholders
	pass

__all__ = ["base_solver", "nr_solver", "pq_solver", "cpf_solver", "tensor_solver"]
