"""Fast Decoupled (PQ) solver scaffold."""

def solve(grid, options=None):
    """Solve power flow using fast decoupled method (placeholder)."""
    raise NotImplementedError
