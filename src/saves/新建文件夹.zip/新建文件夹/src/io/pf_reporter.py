"""Compatibility wrapper exposing powerflow reporting utilities.

This module wraps the existing `ResultReporter` in `src.io.reporter` so
that new import paths like `from src.io import pf_reporter` continue to work.
"""
from .reporter import ResultReporter


def report_powerflow_results(grid, path=None, info=None):
    """Print/export basic PF results using the existing reporter.

    Args:
        grid: power grid instance
        path: unused (kept for API compatibility)
        info: optional info dict passed to `print_node_results`
    """
    rep = ResultReporter(grid)
    rep.print_node_results(info=info)
    return None
