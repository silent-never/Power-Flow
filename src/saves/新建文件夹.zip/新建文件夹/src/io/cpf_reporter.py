"""CPF reporting helpers.

For now this module delegates to the powerflow reporter where appropriate.
"""
from .pf_reporter import report_powerflow_results


def report_cpf_results(cpf_data, path=None):
    """Report CPF run results. `cpf_data` expected to carry a `grid` attribute.

    This is a thin compatibility wrapper to reuse the existing reporter.
    """
    grid = getattr(cpf_data, "grid", None)
    if grid is None:
        raise ValueError("cpf_data must expose a `grid` attribute")
    return report_powerflow_results(grid, path=path)
