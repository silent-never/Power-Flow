"""Visualization wrappers around `src.io.plotter.GridPlotter`.

These thin helpers keep the `visualization` package API while reusing the
fully-featured plotting implementation in `src.io.plotter`.
"""
from ..io.plotter import GridPlotter


def plot_voltage_profile(grid, output_path=None):
    gp = GridPlotter(save_dir=output_path or "output/plots")
    return gp.plot_voltage_profile(grid, save_name="voltage_profile.png")


def plot_all_comparisons(grid, **kwargs):
    gp = GridPlotter(save_dir=kwargs.pop("save_dir", "output/plots"))
    return gp.plot_all_comparisons(grid, **kwargs)


def plot_convergence(info, **kwargs):
    gp = GridPlotter(save_dir=kwargs.pop("save_dir", "output/plots"))
    return gp.plot_convergence(info, **kwargs)
